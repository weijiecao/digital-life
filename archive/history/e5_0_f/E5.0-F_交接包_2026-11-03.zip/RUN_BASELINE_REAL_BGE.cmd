@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0dev"
if "%~1"=="" (
  echo USAGE: RUN_BASELINE_REAL_BGE.cmd "C:\path\to\bge-small-zh-v1.5"
  pause
  exit /b 1
)
echo === Baseline retrieval with real BGE ===
echo Model: %~1
python eval_baseline_retrieval.py --model-dir "%~1"
echo.
echo Result written to dev\reports\baseline_retrieval.json
pause
