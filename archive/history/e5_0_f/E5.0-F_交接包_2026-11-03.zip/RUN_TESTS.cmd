@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0dev"
echo === E5.0-F regression (231 tests) ===
python -m unittest -q test_store test_plugin test_baseline_alignment
if errorlevel 1 (
  echo.
  echo FAILED. Check Python version and dependencies.
  pause
  exit /b 1
)
echo.
echo OK.
pause
