# dev — E5.0-F 下游主插件开发工作区

> 基线：`E5.0-F_0.15.116_工程包`（未改动原件，本目录是可写的开发副本）
> 上游：`DigitalLife_Memory_E50F_Standalone`（已实机验证的 pilot 基线）
> 日期：2026-11-03

## 这个目录是什么

按《项目总结 2026-11-03》的结论，开发继续以 **E5.0-F 插件为主线**，不重写、不引入 V16 依赖。
本目录是这条主线的可写工作区，第一件事是把"能跑"变成"可验证地跑"。

```
dev/
  astrbot_plugin_digital_memory_store/   插件源码（含 P0 修复）
  test_store.py / test_plugin.py         原有 225 项回归
  test_baseline_alignment.py             新增 6 项：上游基线继承
  eval_baseline_retrieval.py             新增：4 案例检索对齐（规则/语义双路径）
  fixtures/                              上游冻结语料（8 条话术 + 3 条旧来源）
  reports/                               评估输出（JSON）
  evaluation/                            原有 15 项场景评估
```

## 第一批改动

| # | 改动 | 原因 |
|---|---|---|
| 1 | `Store.backup()` 显式关闭连接 | `with sqlite3.connect()` 只提交、不关闭；Windows 下锁住备份文件，导致 5 项测试失败 |
| 2 | 测试侧 6 处外部连接改为 `_conn()` 上下文管理器 | 同一反模式的测试侧写法，另导致 3 项失败 |
| 3 | 新增 `test_baseline_alignment.py` | 把上游 8 条冻结话术接入下游，验证继承关系 |

## 当前状态

```
python -m unittest -q test_store test_plugin test_baseline_alignment
Ran 231 tests in ~18s
OK
```

- 原有 225 项：**从 8 个 Windows 错误变为全通过**
- 新增 6 项基线对齐：冻结语料哈希、held-out 不泄漏、单会话采集、幂等与冲突拒绝、0.55 与 4000 字限额继承

## 与上游的继承契约（测试锁定）

| 契约 | 断言位置 |
|---|---|
| 语义索引默认 `min_cosine = 0.55` | `test_inherited_thresholds_and_limits` |
| 单条采集上限 4000 字 | 同上 |
| 8 条话术 = 4 案例（3/2/2/1） | `test_frozen_fixture_structure_and_hashes` |
| 旧来源必须先于新消息 | `test_old_fixture_predates_new_messages` |
| held-out 细节不得出现在新线索 | `test_held_out_details_never_appear_in_new_clues` |
| 单会话、连续 seq、同事务任务 | `test_capture_accepts_baseline_script_in_one_scope` |

## 基线检索对齐结果（2026-11-03）

`python eval_baseline_retrieval.py`，同一批 3 条旧来源 + 4 个案例：

| 模式 | 召回 | 误召回 | held-out 泄漏 |
|---|---|---|---|
| plain（规则） | 0/2 | 0/2 | 0 |
| plain_followup（追问） | 0/2 | 0/2 | 0 |
| weak（弱联想） | 0/2 | 0/2 | 0 |
| weak_followup | 0/2 | 0/2 | 0 |
| **semantic_fixture（受控 4 维替身）** | **2/2** | **0/2** | **0** |

**结论**：
1. 规则路径 0/2 是**结构性的**——上游线索刻意不提事件名（"之前那件事"），字面匹配无从下手；
2. 语义管线接线正确：换受控编码器后 2/2，负例保持空，held-out 不泄漏；
3. 因此**真实 BGE 是硬依赖，不是增强项**：没有模型，下游无法复现上游基线。

> 受控替身只证明"管线通"，不证明"认得准"；准确率仍需真实 BGE。

## 还没做的（按顺序）

1. ~~检索层对齐~~ ✅ 已完成（见上节，`reports/baseline_retrieval.json`）。
2. **真实 BGE**：模型到位后把 `FixtureSemanticEncoder` 换成 `CPUSentenceEmbedder`，重跑 4 个案例，得到第一条真实召回率。
3. **远程实机结果**：按《远程执行单》回传 JSON 后，与本地结果做 A/B 对照。

## 运行

```powershell
cd dev
python -m unittest -q test_store test_plugin test_baseline_alignment
python evaluation/run_scenarios.py
```

> 说明：`_run*.log` 是本地运行日志，可删除。
