# Memory Engine 阶段验收矩阵（2026-11-11 复核后）

- 状态：**NO-GO（R0/R1 均未通过）**
- 全量测试：536/536
- 代码提交：`7a8495a`
- CI：Windows 3.10 / 3.11 / 3.12 全绿
- Memory Engine 真实聊天语料：0
- 宿主：AstrBot 4.29.3 testbed

## 1. 复核后的状态变化

C01/C02/C03 已修复并纳入回归：

| 编号 | 问题 | 修复 |
|---|---|---|
| C01 | hybrid 索引外部失效后仍返回旧条目 | 索引绑定 scope epoch；返回前按当前 revision/valid/pending/withdrawn 再核验 |
| C02 | 零预算/裁剪元数据/无 tokenizer | 零预算空块；框架装不下空块；裁剪后重建 refs/used/degraded；无 tokenizer 默认 strict；CLI 显式 0 保留 |
| C03 | 同故事归一化覆盖原判 | 不改原 proposal；DB 保存 raw_label/raw_reasons/normalization_reason/policy_version |

R0-D 未完成：真实执行的恢复/重放、完整语义快照、独立数据分割、候选包可移植验证。

## 2. M0 基线

| 验收项 | 证据 | 状态 |
|---|---|---|
| 版本/提交冻结 | M0 manifest、R0 包 | ✅ |
| 全量回归 | 536/536；Linux 有 5 项 tiktoken skip | ✅ |
| 关键源文件 SHA | manifest | ✅ |
| 契约/CI | Windows 三版本 | ✅ |

Linux 复核为 526 通过 / 5 skipped；Windows 为 536 通过。报告必须同时写出 skip，不能把 skipped 当已执行。

## 3. M1 一致性

| 验收项 | 证据 | 状态 |
|---|---|---|
| 原子领取/token | lease、双进程 | ✅ |
| 双进程同批竞争 | 最终 DB | ✅ |
| 提交前/后 kill | 子进程 os._exit | ✅ |
| pending 重评 | 注入 + 真实模型单条 | ✅ |
| 真实模型 21 例 | 六次 19–20/21 | ◐ |
| 340 trace | 词面/BGE 多组 | ◐ |
| 部分批次失败保留 | 第 2 条 READY 重试 | ✅ |
| 旧 P/B 反例 | 10/10 通过 | ✅ |

仍缺：恢复执行路径、完整依赖快照、自动触发联合验收。

## 4. M2 数据

| 验收项 | 证据 | 状态 |
|---|---|---|
| 21 例六次 | 20/19/20/20/20/20 | ◐ |
| 340 词面 | F1 0.6286–0.6611，FP0 | ◐ |
| 340 BGE | top20 F1 0.8740/0.8782 | ◐ |
| 簇级 | 词面 0 mixed；BGE 1 mixed | ◐ |
| 来源污染 | 0/311（仅限该口径） | ✅ |
| 冻结输入 SHA | m2_frozen_manifest | ✅ |
| 独立真实 gold | 无 | ❌ |

“污染 0”只表示来源污染；不等于普通事件误合并为 0。BGE 仍有 FP 8–16、mixed 1。

## 5. M3 引擎

| 验收项 | 证据 | 状态 |
|---|---|---|
| ingest/retrieve/context/delete | API/CLI | ✅ |
| 更正/撤回 | 单步/多步 | ✅ |
| 历史链 | history API/CLI | ✅ |
| 真实宿主 shadow 采集 | AstrBot testbed | ✅ |
| 自然更正/时间状态/自动后台 | 无 | ❌ |

## 6. M4 检索

| 验收项 | 证据 | 状态 |
|---|---|---|
| 词面/BGE | R@1 0.7812/0.7937 | ◐ |
| abstain | 默认 1.0；min_score 1.0 → 0 | ◐ |
| 阈值 dev/holdout | holdout 91/91、0 注入（gold 保留，不是 Top1） | ◐ |
| 分 scope | 10/10 | ◐ |
| 真实查询集 | 无 | ❌ |
| C01 索引生命周期 | 已修复，lexical/hybrid 回归 | ✅ |
| BGE 延迟 | p95 41.45ms/1000；约 14.8× 词面 | ◐ |

1.139 是词面阈值，不可直接移植到 RRF 分数；报告必须分开标注。

## 7. M5 上下文

| 验收项 | 证据 | 状态 |
|---|---|---|
| ContextPacket | ✅ | ✅ |
| 摘要 | 抽取式、保留否定 | ✅ |
| 精确 tokenizer | tiktoken（Windows） | ✅ |
| final renderer | fit_packet | ✅ |
| 零预算/裁剪/无 tokenizer | C02 回归 | ✅ |
| 持久缓存 | 四进程共享 | ✅ |
| prune/TTL/janitor | 状态+锁+stale | ✅ |
| 宿主总预算 | HostBudget | ✅ |
| 摘要保真/完整依赖契约 | 未单独验收 | ❌ |

## 8. M6 规模/生命周期

| 验收项 | 证据 | 状态 |
|---|---|---|
| 100k 读/写 | p95/100k | ✅ |
| 100k 备份 | 100k/integrity | ✅ |
| kill 续跑 | 20k/100k | ✅ |
| 多 scope kill 续跑 | 4×25k，0 重复 | ✅ |
| 写锁缺陷 | busy_timeout + BEGIN/release 重试 | ✅ |
| 自动备份 | interval/retention/state/lock | ✅ |
| 恢复后查询/继续写 | 10 hits/151.87ms；receipt1 | ✅ |
| 并发写入时备份 | 20 快照单调，0 错误 | ✅ |
| 复杂业务图/混合负载 | 无 | ❌ |
| 断电/磁盘损坏 | 无；属独立耐久性实验，不是 R0 已冻结必选 | ❌ |

## 9. M7 接入

| 验收项 | 证据 | 状态 |
|---|---|---|
| 真实 AstrBot 启动 | 4.29.3 | ✅ |
| 真实消息链 | OnLLMRequest + 注入 | ✅ |
| Memory Engine shadow | 10 次有效短时运行，52 events/13 scopes | ✅ |
| 回退 | 移出 shadow 后 V1 正常 | ✅ |
| 真实平台 72h | 无 | ❌ |
| 用户效果/生产接管 | 无 | ❌ |

10 次是有效短时运行；另有 5 次环境变量缺失、shadow 未加载的尝试，应保留在部署失败记录中。

## 10. 发布结论

| 层级 | 结论 |
|---|---|
| R0 独立离线文本引擎 | **NO-GO**：C01/C02/C03 已关闭；仍缺真实执行恢复/重放、完整语义快照、独立数据分割、候选包可移植验证、自动闭环证据 |
| R1 目标宿主 | **NO-GO**：无真实平台 72h / 用户效果 |
| Shadow/生产 | **禁止** |

## 11. 主要阻塞

1. R0-D：真实执行的恢复/重放、完整语义快照、独立数据分割、候选包可移植验证。
2. M2/M4：独立真实 gold 与真实查询集；阈值口径仍为合成。
3. M1/M3/M5：自动闭环、自然更正、摘要保真与完整依赖契约。
4. R1：真实 QQ/NapCat 72h 与用户效果。
5. 断电/磁盘损坏：另立耐久性实验，明确当前只证明进程级恢复。
